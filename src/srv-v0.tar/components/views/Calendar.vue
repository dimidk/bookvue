<script setup>
import { onMounted, ref, reactive, useTemplateRef } from 'vue';
import FullCalendar from '@fullcalendar/vue3';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactivePlugin from '@fullcalendar/interaction';
import CreateDialog from '../popups/CreateDialog.vue';
import EventDetails from '../popups/EventDetails.vue';

import { render } from '@fullcalendar/core/preact.js';
import axiosInstance from '../../axios';

const props = defineProps({
    selectedRoom: String,
    bookuser: String
})


const details = reactive({
    id:'',
    bookusername: props.bookuser,
    labname: props.selectedRoom,
    title: '',
    start: '',
    end: '',
    labusername:''
});

const eventDetails = reactive({
    id: '',
    title: '',
    start: '',
    end: ''
});
const text = ref('');
const dialog = ref(null);
const dialogDet = ref(null);

const calendarPlugins = [dayGridPlugin,timeGridPlugin,interactivePlugin];
const emit = defineEmits(['update:selectedRoom']);

const url = '/labs/'+props.selectedRoom;
const fullcalendar = ref(null);
let calAPI = null;
const childRef = useTemplateRef('dialog');
// const EVENTS = null;

onMounted(async () => {

    calAPI = fullcalendar.value.getApi();
    dialog.value;
    dialogDet.value;

    emit('update:selectedRoom', props.selectedRoom);

    //calAPI.refetchEvents();
});



async function changeTimeSlot(arg) {

    console.log(arg.event.id + " "+arg.event.title+" "+arg.event.startStr);

    let recordBook = {
        bookusername: props.bookuser,
        labname: props.selectedRoom,
        id: arg.event.id,
        title: arg.event.title,
        start: arg.event.startStr.slice(0,16).replace('T', ' '),
        end: arg.event.endStr.slice(0,16).replace('T', ' '),
    }

    console.log("all info about modified event "+ recordBook.start +" "+recordBook.end);

    try {
        // let response = await axios.post('http://localhost:8585/api/findBooking',recordBook,{
        //     responseType: 'json',
        //     withCredentials: true
        // });
        let response = await axiosInstance.post('/api/findBooking',recordBook);
        if (response.status === 200) {
            console.log("request ok");
        }
        else {
                console.log("problem with request");
        }

        console.log("record found with data "+response.data);
    }
    catch {
        console.log("error in Axios Post");
    }

};




async function showDetails(arg) {
    console.log("show objct " + arg);
    let idtest = arg.event.id;
    console.log("event id "+idtest);

    console.log("show details " + arg.event.id + " " + arg.event.title +" "+arg.event.start);
    console.log("emitted selected Room ",props.selectedRoom);

    text.value = arg.event.title;
    details.id = arg.event.id;
    details.title = arg.event.title;

    //details.start = arg.event.start.toString().split('GMT')[0];
    details.start = arg.event.startStr.slice(0,16).replace('T', ' ');
    console.log("show details start date in string and bookusername " + details.start + " "+details.bookusername+" "+details.labname);
    
    details.end = arg.event.endStr.slice(0,16).replace('T', ' ');
    details.labname = props.selectedRoom;

    let response = await axiosInstance.post('/api/findBooking',details);

    // let response = await axios.post('http://localhost:8585/api/findBooking',details,{
    //     responseType: 'json',
    //     withCredentials: true
    // });

    if (response.status === 200) {
        console.log("ok request");
    }
    console.log(response.data);
    let data = response.data;

    details.id = data.id;
    details.bookusername = data.bookusername;
    details.labname = data.labname;
    details.title = data.title;
    details.start = data.start;
    details.end = data.end;
    details.labusername = data.labusername;



    if (dialogDet.value) {
        dialogDet.value.openDialog();
    }

}

function deletingEvent(arg) {

    //showDetails(arg);

}

const showComments = (arg) => {
    console.log(arg);
}

async function addingNewEvent(arg) {
    console.log(arg);

    try {
        // let resp = await axios.get('http://localhost:8585/api/all',{
        //     responseType: 'json',
        //     withCredentials: true
        // });
        let resp = await axiosInstance.get('/api/all');
        if (resp.status === 200) {
            console.log("ok");
        }
            
        console.log(resp.data);

        eventDetails.id = Math.floor(resp.data)+1;

        //return resp.data.text;    
    }
    catch {
        console.log("there is an error in request ");
    }

   
    //eventDetails.id = Math.floor(num)+1;
    eventDetails.title = arg.title;
    eventDetails.start = arg.startStr.slice(0,19);
    eventDetails.end = arg.endStr.slice(0,19);

    console.log("details prop " + eventDetails.id + " " +eventDetails.start + " " +eventDetails.end);

    dialog.value.openDialog();
    //calAPI.fireMethod('refetchEvents');
    //fullcalendar.render;

    // render.call();

}

const newBooking = () => {
    dialog.value.openDialog();


}

</script>




<template>
<!-- <section>
    <h4>
       {{ bookuser }}
    </h4>
</section> -->
    

 <!-- <CreateDialog ref="dialog" :bookuser="bookuser" v-if="boolenText === 'true'" :details="eventDetails"/> -->
 <CreateDialog ref="dialog" :bookuser="bookuser" :details="eventDetails"/>
 <EventDetails ref="dialogDet" v-if="text !== ''" :bookuser="bookuser" :event="details"/>
 <section>
    <button @click="newBooking" class="btn">Νέα Κράτηση</button>
 </section>
  
    <FullCalendar ref="fullcalendar"
             
             :options="{
                 initialView: 'timeGridWeek',
                 plugins: [timeGridPlugin,dayGridPlugin,interactivePlugin],
                 headerToolbar: {
                     left: 'timeGridWeek',
                     center: 'title',
                     right: 'prev today next'
                 },
                 
                 selectable: true,
                 selectOverlap: false,
                 selectConstraint: {
                     start: '00:01',
                     end: '23:59'
                 },
                 eventDurationEditable: true,
                 slotMinTime: '08:00',
                 slotMaxTime: '20:00',
                 height: 'auto',
                 width: 'auto',
                 //currentEvents: [],
                 //events: {
                    // {
                    //     title: 'Something Java',
                    //     start: '2025-02-28T10:30',
                    //     end: '2025-02-28T11:30'
                    // },
                    // {
                    //     title: 'Something Java',
                    //     start: '2025-03-01T11:30:00',
                    //     end: '2025-03-01T15:30:00'
                    // },
                    //  url: 'http://localhost:8585/labs/'+props.selectedRoom
                    // url: axiosInstance.get('/labs/'+props.selectedRoom),
                    //  type: 'GET',
                    //  color: '#FFB107',
                    //  textColor: 'black'
                 //},
                 events: async (info, successCallback, failureCallback) => {
                    try {
                        const response = await axiosInstance.get(`/labs/${props.selectedRoom}`);
                        const events = response.data.map(event => ({
                            id: event.id,
                            title: event.title,
                            start: event.start,
                            end: event.end
                        }));
                        successCallback(events);
                    } catch (error) {
                        console.error('Error fetching events:', error);
                        failureCallback(error);
                    }
                 },
                 eventOverlap: false,
                 select: addingNewEvent,
                 eventClick: showDetails,
                 eventChange: changeTimeSlot,
                 eventAdd: test,
                 eventDrop: deletingEvent,
                 renderEvent: showComments
             }"
               />
 




</template>
<style scoped>
@import '../../assets/fullcalendar.css';
@import '../../assets/assets_css_fullcalendar.print.css';




</style>