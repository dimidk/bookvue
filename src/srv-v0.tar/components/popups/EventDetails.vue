<script setup>
import { nextTick, onMounted, reactive, ref, watch } from 'vue';
//import axios from 'axios';
import axiosInstance from '../../axios';

const props = defineProps({
    event: {
        id: String,
        bookusername: String,
        labname: String,
        title: String,
        start: String,
        end: String,
        labusername: String
    },
    bookuser: String
})

const eventToShow = reactive({

    id: props.event.id,
    title: props.event.title,
    start: props.event.start.slice(0,16).replace('T',' '),
    end: props.event.end.slice(0,16).replace('T',' '),
    labname: props.event.labname,
    bookusername: props.event.bookusername,
    labusername: props.event.labusername

})

//const authorizeToDelete = ref(false);

const dialog=ref(null);

const openDialog = async () => {

    await nextTick();
    if (dialog.value) {
        dialog.value.showModal();
    }
    else {
        console.log("dialog is null");
    }
  };

const closeDialog = () => {

    if (dialog.value)
        dialog.value.close();
};

watch(props.event, (newEventToShow) => {

    if (newEventToShow) {

        console.log(newEventToShow);
    }

    console.log(props.event.bookusername);
    console.log(props.event.id);
    console.log(props.event.title);
    console.log(props.event.start.slice(0,16).replace('T',' '));
    console.log(props.event.end.slice(0,16).replace('T',' '));
    console.log(props.event.labname);
    console.log(props.event.labusername);

    console.log("new event to show details");
    console.log(newEventToShow.title);
    console.log(newEventToShow.start);
    console.log(newEventToShow.end);

    eventToShow.id = newEventToShow.id;
    eventToShow.title = newEventToShow.title;
    eventToShow.start = newEventToShow.start;
    eventToShow.end = newEventToShow.end;
    eventToShow.labname = newEventToShow.labname;
    eventToShow.bookusername = newEventToShow.bookusername;
    eventToShow.labusername = newEventToShow.labusername;

    console.log("logged user", props.bookuser);
    if (eventToShow.bookusername === props.bookuser) {
      console.log("change authorizeToDelete value");
       // authorizeToDelete.value = true;
    }

    console.log(eventToShow);

},
{ immediate: true});

// onMounted( async () => {

//     console.log(eventToShow.bookusername+ " "+eventToShow.id+ " "+eventToShow.labusername+" "+eventToShow.title);

//     let response = await axios.post('http://localhost:8585/api/findBooking',eventToShow,{
//         responseType: 'json',
//         withCredentials: true
//     });

//     if (response.status === 200) {
//         console.log("ok request");
//     }
//     console.log(response.data);

//     eventToShow.id = response.data.id;

//     if (response.data.bookusername === eventToShow.bookusername) {
//         authorizeToDelete.value = true;
//     }

//     eventToShow.bookusername = response.data.bookusername;
//     eventToShow.labname = response.data.labname;
//     eventToShow.title = response.data.title;
//     eventToShow.start = response.data.start;
//     eventToShow.end = response.data.end;
//     eventToShow.labusername = response.data.labusername;

// })


function updateEvent(arg) {

}

async function deleteEvent() {

    // console.log("event to delete " + props.event.title + " " + props.event.start + " "+props.event.bookusername);

    // const eventToDelete = {
    //     bookusername: props.event.bookusername,
    //     labname: props.event.labname,
    //     id: props.event.id,
    //     title: props.event.title,
    //     start: props.event.start,
    //     end: props.event.end
    // }

    // console.log("eventToDelete startdate:" + eventToDelete.start + " end date:" + eventToDelete.end + " bookuser:"+eventToDelete.bookusername);
    // console.log("eventToDelete eventId:"+eventToDelete.id);

    //send record request with current logged user
    //eventToShow.bookusername = props.event.bookusername;

    try {
        // let response = await axios.post('http://localhost:8585/api/delete',eventToShow,
        //     {responseType: 'json',
        //         withCredentials: true
        //     }
        // );
        let response = await axiosInstance.post('/api/delete',eventToShow);
        if (response.status === 200) {
            console.log("Http Request OK");
        }
        else {
            console.log("Http Request problem");
        }
        let data = response.data;
        console.log("response bookuser and eventToDelete bookuser "+ data.bookusername + " " + props.event.bookusername);
        console.log("response data id and eventToShow id",data.id,eventToShow.id);
        //console.log("authorize to delete "+authorizeToDelete.value);
        if (data.bookusername !== props.bookuser) {
        //if (authorizeToDelete.value === false) {
            alert("You are not authorized to delete");
        }
        //authorizeToDelete.value = false;
    }
    catch(error) {
        console.log("error in fetching deletion data ", error);
    }

    closeDialog();

    //console.log(response);

}

  defineExpose({openDialog,closeDialog});

</script>

<template>
    <div>
        <dialog ref="dialog" v-if="event">
            {{ bookuser }}
        <fieldset>
           <h3>Event Details</h3>
           
            <fieldset>
                <b>  Title:</b> {{ eventToShow.title }}
            </fieldset>
            <fieldset>
                <b>  Start: </b>{{ eventToShow.start }}
            </fieldset>
            <fieldset>
                <b>  End: </b>{{ eventToShow.end }}
            </fieldset>

            <fieldset>
                <b>  Booked By: </b> {{ eventToShow.bookusername }}
            </fieldset>
            <fieldset>
                <b>  Lab: </b> {{ eventToShow.labname }}
            </fieldset>
            <fieldset>
                <b>  Author: </b> {{ eventToShow.labusername }}
            </fieldset>
        
        </fieldset>
        <hr>
        <form @submit.prevent="updateEvent">
        <fieldset>
            <legend>Update Event</legend>
            <div>
                <label for="changeInfo">Add description</label>
                <input id="changeInfo" type="text" v-model="title">
            </div>
            <div>
                <label for="changeDateStart">Change start date</label>
                <input id="changeDateStart" type="date" v-model="start">
            </div>
            <div>
                <label for="changeDateEnd">Change end date</label>
                <input id="changeDateEnd" type="date" v-model="end">
            </div>
            
            <div>
                <button type="submit" >Update</button>
                <!-- <button type="submit" @click="updateEvent">Update</button> -->
                <button type="button" @click="deleteEvent">Delete</button>
                <button  @click="closeDialog">Close</button>
            </div>
        </fieldset>
    </form>
    </dialog>
    </div>


</template>