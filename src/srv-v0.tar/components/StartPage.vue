<script setup>
// import Login from './LoginFolder/Login.vue';
// import Register from './LoginFolder/Register.vue';

    const link="http://localhost:8585/registeredUsers";

 

</script>

<template>
    <h1>Booking Online Application</h1>
  
    <div>
        <button><router-link to="/login">Login</router-link></button>
        <button>
            <router-link to="/register">Register</router-link>
        </button>
    </div>
    <div>
        <a :href="link">For Registered Users</a>
    </div>
    
    
  
    <!-- <div class="container">
        <button @click="login">Login</button>
        <button @click="register">Register</button>
        
    </div> -->
    <!-- <Login />
    <Register /> -->

</template>